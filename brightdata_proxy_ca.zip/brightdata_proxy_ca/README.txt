All new projects must use the **new** SSL certificate: brightdata_root_ca_44445.crt
Effective from July 2026.
The new certificate requires connecting to Bright Data's proxy network via port 44445 — even where documentation or sample code still references port 33335. Docs will be gradually updated as the old certificate is phased out.

The old certificate is retained for reference only: legacy/brightdata_root_ca_33335.crt

Full usage instructions: https://docs.brightdata.com/general/account/ssl-certificate
